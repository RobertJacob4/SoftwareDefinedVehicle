#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
# This code was generated automatically. Changes to this file may
# cause incorrect behavior and will be lost if the code is regenerated.

from vector.canoe.cla import ValueUpdateMode_OnChange, ValueUpdateMode_OnUpdate, InterfaceValueEntityCallbackFunction, InterfaceValueEntityCallbackFunctionInterface, InterfaceConsumerCallContextCallbackFunction, InterfaceConsumerCallContextCallbackFunctionInterface, InterfaceProviderCallContextCallbackFunction, InterfaceProviderCallContextCallbackFunctionInterface
from . import typelib_common as typelib_common
from . import typelib_cla_service as typelib_cla_service
from .typelib_field_member import GetterMixin, SetterMixin

createInterfaceValueEntityCallbackFunction = typelib_common.getCreateCallbackFunction(InterfaceValueEntityCallbackFunction, InterfaceValueEntityCallbackFunctionInterface)
createInterfaceConsumerCallContextCallbackFunction = typelib_common.getCreateCallbackFunction(InterfaceConsumerCallContextCallbackFunction, InterfaceConsumerCallContextCallbackFunctionInterface)
createInterfaceProviderCallContextCallbackFunction = typelib_common.getCreateCallbackFunction(InterfaceProviderCallContextCallbackFunction, InterfaceProviderCallContextCallbackFunctionInterface)


class DOInterface:
    def __init__(self, path, do_interface_impl):
        self._do_interface = typelib_cla_service.service.GetDoInterface(path)
        self._do_interface_impl = do_interface_impl


class InterfaceMemberObservable:    
    def _register_handler_generic(self, map, create_fct, register_fct, callback, *addCallbackArgs):
        if (callback not in map.keys()):
            cbWrapper = create_fct(lambda *args: self._call_callback(callback, *args, *addCallbackArgs))
            cbHandle = register_fct(cbWrapper)
            map[callback] = cbHandle
            
    def _unregister_handler_generic(self, map, callback):
        if (callback in map.keys()):
            self._do_interface_member.UnregisterCallback(map[callback])
            map.pop(callback)


class InterfaceAnyChangeMixin:    
    def register_on_any_changed_handler(self, callback):
        self._register_handler_generic(self._on_change_map, createInterfaceValueEntityCallbackFunction, lambda cb:self._do_interface_member.RegisterCallback(cb, ValueUpdateMode_OnChange), callback)

    def unregister_on_any_changed_handler(self, callback):
        self._unregister_handler_generic(self._on_change_map, callback)


class InterfaceAnyUpdateMixin:    
    def register_on_any_update_handler(self, callback):
        self._register_handler_generic(self._on_update_map, createInterfaceValueEntityCallbackFunction, lambda cb:self._do_interface_member.RegisterCallback(cb, ValueUpdateMode_OnUpdate), callback)

    def unregister_on_any_update_handler(self, callback):
        self._unregister_handler_generic(self._on_update_map, callback)
 

class InterfaceValueEntityBase(InterfaceMemberObservable):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        self._do_impl_dt = do_interface._do_interface_impl
        self._member_path = member_path
        self._do_interface_member = do_interface_member
        self._on_change_map = {}
        self._on_update_map = {}
        
    def _call_callback(self, callback, do, ve):
        py_do = self._do_impl_dt(do.GetPath(), "", do)
        callback(py_do)


class InterfaceValueEntity(InterfaceValueEntityBase, InterfaceAnyUpdateMixin, InterfaceAnyChangeMixin):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        super().__init__(do_interface, do_interface_member, member_path)


class InterfaceVoidEvent(InterfaceValueEntityBase, InterfaceAnyUpdateMixin):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        super().__init__(do_interface, do_interface_member, member_path)


class InterfaceCallContext(InterfaceMemberObservable):
    def __init__(self, do_interface, cco_dt, do_interface_member, member_path: str):
        self._do_impl_dt = do_interface._do_interface_impl
        self._cco_dt = cco_dt
        self._member_path = member_path
        self._do_interface_member = do_interface_member

    def _call_callback(self, callback, do, cco, prefer_out_values: bool, stored_in_raw: bool, stored_out_raw: bool):
        py_do = self._do_impl_dt(do.GetPath(), "", do)
        py_cco = self._cco_dt(cco, prefer_out_values, stored_in_raw, stored_out_raw)
        callback(py_do, py_cco)


class InterfaceProvidedCallContext(InterfaceCallContext):
    _stored_in_raw = True
    _stored_out_raw = False
    def __init__(self, do_interface, cco_dt, do_interface_member, member_path: str):
        InterfaceCallContext.__init__(self, do_interface, cco_dt, do_interface_member, member_path)
        self._on_calling_map = {}
        self._on_called_map = {}
        self._on_returning_map = {}

    def register_on_any_calling_handler(self, callback):   
        self._register_handler_generic(self._on_calling_map, createInterfaceProviderCallContextCallbackFunction, lambda cb: self._do_interface_member.RegisterCallingCallback(cb), callback, False, self._stored_in_raw, self._stored_out_raw)
     
    def register_on_any_called_handler(self, callback):   
        self._register_handler_generic(self._on_called_map, createInterfaceProviderCallContextCallbackFunction, lambda cb: self._do_interface_member.RegisterCalledCallback(cb), callback, True, self._stored_in_raw, self._stored_out_raw)

    def register_on_any_returning_handler(self, callback):   
        self._register_handler_generic(self._on_returning_map, createInterfaceProviderCallContextCallbackFunction, lambda cb: self._do_interface_member.RegisterReturningCallback(cb), callback, True, self._stored_in_raw, self._stored_out_raw)
        
    def unregister_on_any_calling_handler(self, callback):
        self._unregister_handler_generic(self._on_calling_map, callback)

    def unregister_on_any_called_handler(self, callback):
        self._unregister_handler_generic(self._on_called_map, callback)
    
    def unregister_on_any_returning_handler(self, callback):
        self._unregister_handler_generic(self._on_returning_map, callback)


class InterfaceConsumedCallContext(InterfaceCallContext):
    _stored_in_raw = False
    _stored_out_raw = True
    def __init__(self, do_interface, cco_dt, do_interface_member, member_path: str):
        InterfaceCallContext.__init__(self, do_interface, cco_dt, do_interface_member, member_path)
        self._on_returned_map = {}

    def register_on_any_returned_handler(self, callback):   
        self._register_handler_generic(self._on_returned_map, createInterfaceConsumerCallContextCallbackFunction, lambda cb: self._do_interface_member.RegisterReturnedCallback(cb), callback, True, self._stored_in_raw, self._stored_out_raw)
     
    def unregister_on_any_returned_handler(self, callback):
        self._unregister_handler_generic(self._on_returned_map, callback)


class InterfaceInternalCallContext(InterfaceProvidedCallContext, InterfaceConsumedCallContext):
    _stored_in_raw = False
    _stored_out_raw = False
    def __init__(self, do_interface, cco_dt, do_interface_member, member_path: str):
        InterfaceCallContext.__init__(self, do_interface, cco_dt, do_interface_member, member_path)


class InterfaceProvidedFieldBase(InterfaceValueEntity):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_cco_type, setter_cco_type):
        super().__init__(do_interface, do_interface_member, member_path)
        if getter_cco_type:
            self._getter = InterfaceProvidedCallContext(do_interface, getter_cco_type, do_interface_member.GetProvidedGetter(), member_path + ".Get")
        if setter_cco_type:
            self._setter = InterfaceProvidedCallContext(do_interface, setter_cco_type, do_interface_member.GetProvidedSetter(), member_path + ".Set")


class InterfaceConsumedFieldBase(InterfaceValueEntity):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_cco_type, setter_cco_type):
        super().__init__(do_interface, do_interface_member, member_path)
        if getter_cco_type:
            self._getter = InterfaceConsumedCallContext(do_interface, getter_cco_type, do_interface_member.GetConsumedGetter(), member_path + ".Get")
        if setter_cco_type:
            self._setter = InterfaceConsumedCallContext(do_interface, setter_cco_type, do_interface_member.GetConsumedSetter(), member_path + ".Set")


class InterfaceInternalFieldBase(InterfaceValueEntity):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_cco_type, setter_cco_type):
        super().__init__(do_interface, do_interface_member, member_path)
        if getter_cco_type:
            self._getter = InterfaceInternalCallContext(do_interface, getter_cco_type, do_interface_member.GetInternalGetter(), member_path + ".Get")
        if setter_cco_type:
            self._setter = InterfaceInternalCallContext(do_interface, setter_cco_type, do_interface_member.GetInternalSetter(), member_path + ".Set")


class InterfaceProvidedFieldGetSet(InterfaceProvidedFieldBase, GetterMixin[InterfaceProvidedCallContext], SetterMixin[InterfaceProvidedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, setter_type)


class InterfaceConsumedFieldGetSet(InterfaceConsumedFieldBase, GetterMixin[InterfaceConsumedCallContext], SetterMixin[InterfaceConsumedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, setter_type)


class InterfaceInternalFieldGetSet(InterfaceInternalFieldBase, GetterMixin[InterfaceInternalCallContext], SetterMixin[InterfaceInternalCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, setter_type)


class InterfaceProvidedFieldGet(InterfaceProvidedFieldBase, GetterMixin[InterfaceProvidedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, None)


class InterfaceConsumedFieldGet(InterfaceConsumedFieldBase, GetterMixin[InterfaceConsumedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, None)


class InterfaceInternalFieldGet(InterfaceInternalFieldBase, GetterMixin[InterfaceInternalCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, getter_type):
        super().__init__(do_interface, do_interface_member, member_path, getter_type, None)


class InterfaceProvidedFieldSet(InterfaceProvidedFieldBase, SetterMixin[InterfaceProvidedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, None, setter_type)


class InterfaceConsumedFieldSet(InterfaceConsumedFieldBase, SetterMixin[InterfaceConsumedCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, None, setter_type)


class InterfaceInternalFieldSet(InterfaceInternalFieldBase, SetterMixin[InterfaceInternalCallContext]):
    def __init__(self, do_interface, do_interface_member, member_path: str, setter_type):
        super().__init__(do_interface, do_interface_member, member_path, None, setter_type)


class InterfaceProvidedField(InterfaceProvidedFieldBase):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        super().__init__(do_interface, do_interface_member, member_path, None, None)


class InterfaceConsumedField(InterfaceConsumedFieldBase):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        super().__init__(do_interface, do_interface_member, member_path, None, None)


class InterfaceInternalField(InterfaceInternalFieldBase):
    def __init__(self, do_interface, do_interface_member, member_path: str):
        super().__init__(do_interface, do_interface_member, member_path, None, None)



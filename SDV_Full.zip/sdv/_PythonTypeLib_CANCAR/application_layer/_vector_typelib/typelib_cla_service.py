# This code was generated automatically. Changes to this file may
# cause incorrect behavior and will be lost if the code is regenerated.

from enum import IntEnum
import vector.canoe.cla

service = vector.canoe.cla.CreateClaService()


#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
# This code was generated automatically. Changes to this file may
# cause incorrect behavior and will be lost if the code is regenerated.

from typing import TypeVar, Generic, Callable
from . import typelib_do as typelib_do
from . import typelib_cla_service as typelib_cla_service

T = TypeVar("T")

class DOGeneralContainerImpl(Generic[T]):
    def __init__(self, path, dt, min_size, max_size, do_container = None) -> None:
        if do_container == None:
            self._do_container = typelib_cla_service.service.GetDoInstContainer(path)
        else: 
            self._do_container = do_container
        self._dt = dt        
        self._path = path
        self._min_size = min_size
        self._max_size = max_size

    @property
    def path(self) -> str:
        return self._path

    def __len__(self) -> int:
        return self._do_container.GetSize()
 
    def push_back(self):
        length = len(self)

        if self._max_size != -1 and length == self._max_size:
           raise IndexError(f"Container has the maximal size already.")

        self._do_container.Resize(length + 1)

    def pop_back(self):
        length = len(self)

        if length == self._min_size:
           raise IndexError(f"Container has the minimal size already.")

        self._do_container.Resize(length-1)

    def __getitem__(self, index: int) -> T:
        if index >= len(self) or index < 0:
           raise IndexError(f"Index out of range.")

        val = self._do_container.GetElement(index)
        if val == None:
           raise IndexError(f"Index out of range.") 
        
        if DOContainerImpl in self._dt.__bases__:
            subcontainer = val.GetContainer()
            if subcontainer != None:
                return self._dt(self._path + f"[{index}]", subcontainer)
            else:
                raise RuntimeError(f"Internal error.") 
        else:
            do = val.GetDo()
            if do != None:
                return self._dt(self._path + f"[{index}]", "", do)
            else:
                raise RuntimeError(f"Internal error.") 


class DOContainerImpl(DOGeneralContainerImpl[T], Generic[T]):
    def __init__(self, path, dt, min_size, max_size, do_container = None) -> None:
        super().__init__(path, dt, min_size, max_size, do_container)

    def create(self, index: int):
        if (self._max_size != -1 and index >= self._max_size) or index < 0:
           raise IndexError(f"Index out of range.")
        
        val = self._do_container.GetElement(index)
        if val == None:
           raise IndexError(f"Index out of range.")

        do = val.CreateDo() 

    def erase(self, index: int):
        if index >= len(self) or index < 0:
           raise IndexError(f"Index out of range.")
        
        val = self._do_container.GetElement(index)
        if val == None:
           raise IndexError(f"Index out of range.") 

        do = val.DestroyDo()


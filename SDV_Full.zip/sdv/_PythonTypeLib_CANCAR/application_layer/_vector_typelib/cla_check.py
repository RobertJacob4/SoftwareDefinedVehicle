#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
# This code was generated automatically. Changes to this file may
# cause incorrect behavior and will be lost if the code is regenerated.

try:
    import vector.canoe
except ModuleNotFoundError:
    raise ModuleNotFoundError("The vector.canoe package is missing. This type library must be loaded by CANoe and then the package will be found.")

SAB_CLA = "SabCla"
CANOE_CLA = "CANoeCla"
REQUIRED_CLA_VERSION = "6.0.0"


def check_version():
    required_version = REQUIRED_CLA_VERSION.split('.')
    required_major = int(required_version[0])
    required_minor = int(required_version[1])
    required_patch = int(required_version[2])
    implementation_version = vector.canoe.cla.GetImplementationVersion()
    if(implementation_version.major != required_major or (required_minor, required_patch) > (implementation_version.minor, implementation_version.patch)):
        raise VersionException(str(implementation_version.major) + '.' + str(implementation_version.minor) + '.' + str(implementation_version.patch))


class VersionException(Exception):
    def __init__(self, *args):
        self.message = args[0]

    def __str__(self):
        return 'The canoe-sil-adapter-runtime package version is incompatible: {0} suited {1}. Please update the canoe-sil-adapter-runtime package and regenerate the SIL Adapter.'.format(self.message, REQUIRED_CLA_VERSION)

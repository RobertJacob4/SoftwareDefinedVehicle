from . import typelib_method_member
from typing import TypeVar, Generic
from . import typelib_common as typelib_common
from . import typelib_do as typelib_do

T = TypeVar("T")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
T4 = TypeVar("T4")
T5 = TypeVar("T5", bound=typelib_method_member.MethodBase)
T6 = TypeVar("T6", bound=typelib_method_member.MethodBase)


class ProvidedFieldBase(typelib_common.ValueEntityWithDataType, typelib_common.OnUpdateMixin, typelib_common.OnChangeMixin, typelib_common.SetMixin[T], Generic[T]):
    def __init__(self: object, doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, has_event):
        member = doInterfaceImpl._do.GetProvidedField(embedded_prefix +  do_member_name, tx_trigger)
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, member.GetValue(), dt, stored_raw)
        if getter_type != None:
            self._getter = getter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Get", method=member.GetProvidedGetter())    
        if setter_type != None:
            self._setter = setter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Set", method=member.GetProvidedSetter())
        if has_event:
            self._event = member.GetProvidedEvent()


class ConsumedFieldBase(typelib_common.ValueEntityWithDataType, typelib_common.OnUpdateMixin, typelib_common.OnChangeMixin, Generic[T]):
    def __init__(self: object, doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, has_event):
        member = doInterfaceImpl._do.GetConsumedField(embedded_prefix +  do_member_name)
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, member.GetValue(), dt, True)
        if getter_type != None:
            self._getter = getter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Get", method=member.GetConsumedGetter())    
        if setter_type != None:
            self._setter = setter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Set", method=member.GetConsumedSetter())
        if has_event:
            self._event = member.GetConsumedEvent()

            
class InternalFieldBase(typelib_common.ValueEntityWithDataType, typelib_common.OnUpdateMixin, typelib_common.OnChangeMixin, typelib_common.SetMixin[T], Generic[T]):
    def __init__(self: object, doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, has_event):
        member = doInterfaceImpl._do.GetInternalField(embedded_prefix +  do_member_name)
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, member.GetValue(), dt, False)
        if getter_type != None:
            self._getter = getter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Get", method=member.GetInternalGetter())    
        if setter_type != None:
            self._setter = setter_type(do=doInterfaceImpl, doMethodPath=f"{self._doMemberPath}.Set", method=member.GetInternalSetter())
        if has_event:
            self._event = member.GetInternalEvent()



class GetterMixin(Generic[T]):
    @property
    def get(self) -> T:
        return self._getter


class SetterMixin(Generic[T]):
    @property
    def set(self) -> T:
        return self._setter


class NotifyMixin:
    # def subscribe(self):
    #     pass

    # def unsubscribe(self):
    #     pass
    pass


class ProvidedConversionPhysRawSymbGetSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedConversionPhysRawSymbGetSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalConversionPhysRawSymbGetSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedConversionPhysRawGetSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedConversionPhysRawGetSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalConversionPhysRawGetSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedConversionRawGetSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedConversionRawGetSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalConversionRawGetSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedConversionPhysSymbGetSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedConversionPhysSymbGetSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalConversionPhysSymbGetSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedConversionPhysGetSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedConversionPhysGetSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalConversionPhysGetSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedGetSetNotifyField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, True)


class ConsumedGetSetNotifyField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class InternalGetSetNotifyField(InternalFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], NotifyMixin, Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, True)


class ProvidedConversionPhysRawSymbGetSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedConversionPhysRawSymbGetSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalConversionPhysRawSymbGetSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedConversionPhysRawGetSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedConversionPhysRawGetSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalConversionPhysRawGetSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedConversionRawGetSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedConversionRawGetSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalConversionRawGetSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], GetterMixin[T5], Generic[T, T3, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedConversionPhysSymbGetSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedConversionPhysSymbGetSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalConversionPhysSymbGetSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T4, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedConversionPhysGetSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedConversionPhysGetSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalConversionPhysGetSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], GetterMixin[T5], Generic[T, T2, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedGetSetField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, setter_type, False)


class ConsumedGetSetField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class InternalGetSetField(InternalFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], GetterMixin[T5], Generic[T, T5, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, setter_type, False)


class ProvidedConversionPhysRawSymbGetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedConversionPhysRawSymbGetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalConversionPhysRawSymbGetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedConversionPhysRawGetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedConversionPhysRawGetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalConversionPhysRawGetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedConversionRawGetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedConversionRawGetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalConversionRawGetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], NotifyMixin, Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedConversionPhysSymbGetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedConversionPhysSymbGetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalConversionPhysSymbGetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], NotifyMixin, Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedConversionPhysGetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedConversionPhysGetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalConversionPhysGetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], GetterMixin[T5], NotifyMixin, Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedGetNotifyField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], NotifyMixin, Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, True)


class ConsumedGetNotifyField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], NotifyMixin, Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class InternalGetNotifyField(InternalFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], NotifyMixin, Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, True)


class ProvidedConversionPhysRawSymbGetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedConversionPhysRawSymbGetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalConversionPhysRawSymbGetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T3, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedConversionPhysRawGetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedConversionPhysRawGetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], GetterMixin[T5], Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalConversionPhysRawGetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], Generic[T, T2, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedConversionRawGetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedConversionRawGetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], GetterMixin[T5], Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalConversionRawGetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], GetterMixin[T5], Generic[T, T3, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedConversionPhysSymbGetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedConversionPhysSymbGetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalConversionPhysSymbGetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], GetterMixin[T5], Generic[T, T2, T4, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedConversionPhysGetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], GetterMixin[T5], Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedConversionPhysGetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], GetterMixin[T5], Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalConversionPhysGetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], GetterMixin[T5], Generic[T, T2, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedGetField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, getter_type, None, False)


class ConsumedGetField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class InternalGetField(InternalFieldBase[T], typelib_common.CopyMixin[T], GetterMixin[T5], Generic[T, T5]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type: T5):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, getter_type, None, False)


class ProvidedConversionPhysRawSymbSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedConversionPhysRawSymbSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalConversionPhysRawSymbSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedConversionPhysRawSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedConversionPhysRawSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalConversionPhysRawSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedConversionRawSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedConversionRawSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalConversionRawSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], NotifyMixin, Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedConversionPhysSymbSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedConversionPhysSymbSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalConversionPhysSymbSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], NotifyMixin, Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedConversionPhysSetNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], NotifyMixin, Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedConversionPhysSetNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], SetterMixin[T6], NotifyMixin, Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalConversionPhysSetNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], NotifyMixin, Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedSetNotifyField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], NotifyMixin, Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, True)


class ConsumedSetNotifyField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], NotifyMixin, Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class InternalSetNotifyField(InternalFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], NotifyMixin, Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, True)


class ProvidedConversionPhysRawSymbSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedConversionPhysRawSymbSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalConversionPhysRawSymbSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T3, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedConversionPhysRawSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedConversionPhysRawSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalConversionPhysRawSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], Generic[T, T2, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedConversionRawSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedConversionRawSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], SetterMixin[T6], Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalConversionRawSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], SetterMixin[T6], Generic[T, T3, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedConversionPhysSymbSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedConversionPhysSymbSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalConversionPhysSymbSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], SetterMixin[T6], Generic[T, T2, T4, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedConversionPhysSetField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedConversionPhysSetField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], SetterMixin[T6], Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalConversionPhysSetField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], SetterMixin[T6], Generic[T, T2, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedSetField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, setter_type, False)


class ConsumedSetField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class InternalSetField(InternalFieldBase[T], typelib_common.CopyMixin[T], SetterMixin[T6], Generic[T, T6]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, setter_type: T6):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, setter_type, False)


class ProvidedConversionPhysRawSymbNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], NotifyMixin, Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedConversionPhysRawSymbNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], NotifyMixin, Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalConversionPhysRawSymbNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], NotifyMixin, Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedConversionPhysRawNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], NotifyMixin, Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedConversionPhysRawNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], NotifyMixin, Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalConversionPhysRawNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], NotifyMixin, Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedConversionRawNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], NotifyMixin, Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedConversionRawNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], NotifyMixin, Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalConversionRawNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], NotifyMixin, Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedConversionPhysSymbNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], NotifyMixin, Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedConversionPhysSymbNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], NotifyMixin, Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalConversionPhysSymbNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], NotifyMixin, Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedConversionPhysNotifyField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], NotifyMixin, Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedConversionPhysNotifyField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], NotifyMixin, Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalConversionPhysNotifyField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], NotifyMixin, Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedNotifyField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], NotifyMixin, Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, True)


class ConsumedNotifyField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], NotifyMixin, Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class InternalNotifyField(InternalFieldBase[T], typelib_common.CopyMixin[T], NotifyMixin, Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, True)


class ProvidedConversionPhysRawSymbField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedConversionPhysRawSymbField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalConversionPhysRawSymbField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T3, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class ProvidedConversionPhysRawField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedConversionPhysRawField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalConversionPhysRawField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T2, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class ProvidedConversionRawField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedConversionRawField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalConversionRawField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T3]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class ProvidedConversionPhysSymbField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedConversionPhysSymbField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalConversionPhysSymbField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T4]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class ProvidedConversionPhysField(ProvidedFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedConversionPhysField(ConsumedFieldBase[T], typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalConversionPhysField(InternalFieldBase[T], typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], Generic[T, T2]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class ProvidedField(ProvidedFieldBase[T], typelib_common.CopyMixin[T], Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, stored_raw, tx_trigger, None, None, False)


class ConsumedField(ConsumedFieldBase[T], typelib_common.CopyMixin[T], Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)


class InternalField(InternalFieldBase[T], typelib_common.CopyMixin[T], Generic[T]):
    def __init__(self, doInterfaceImpl: typelib_do.DoInterfaceImpl, embedded_prefix, do_member_name, dt):
        super().__init__(doInterfaceImpl, embedded_prefix, do_member_name, dt, None, None, False)




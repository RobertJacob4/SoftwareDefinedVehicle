#
# Copyright (c) Vector Informatik GmbH. All rights reserved.
#
# This code was generated automatically. Changes to this file may
# cause incorrect behavior and will be lost if the code is regenerated.

import vector.canoe.cla

import weakref
from typing import TypeVar, Callable, List, Generic
from enum import IntEnum
from . import typelib_common as typelib_common
from . import typelib_base_datatypes as typelib_base_datatypes
from vector.canoe import OutParameter, InOutParameter

createConsumerCallContextCallbackFunction = typelib_common.getCreateCallbackFunction(vector.canoe.cla.ConsumerCallContextCallbackFunction, vector.canoe.cla.ConsumerCallContextCallbackFunctionInterface)
createProviderImplementationCallbackFunction = typelib_common.getCreateCallbackFunction(vector.canoe.cla.ProviderImplementationCallbackFunction, vector.canoe.cla.ProviderImplementationCallbackFunctionInterface)


T = TypeVar("T")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
T4 = TypeVar("T4")


class ParamInOutEnum(IntEnum):
    In = 0
    Out = 1
    InOut = 2


class ParamDef:
    def __init__(self, name: str, datatype: object, inout_type: ParamInOutEnum, is_opt: bool):
        self.name = name
        self.datatype = datatype
        self.inout_type = inout_type
        self.is_opt = is_opt


def list_to_ParamDef(param_list):
    return [ParamDef(*y) for y in param_list]


def _conv_serialization_param(serializer, effdt, optDt, val):
    conversableValue = effdt()
    conversableValue.impl_value = val
    optDt.serialize(serializer, conversableValue, False)


def _is_conv_type(dt) -> bool:
    return isinstance(dt, type) and issubclass(dt, typelib_base_datatypes.DataTypeWithConversion)


def _is_primitive_type(dt) -> bool:
    return dt in (typelib_base_datatypes.BoolDataType, typelib_base_datatypes.DoubleDataType, typelib_base_datatypes.FloatDataType,
        typelib_base_datatypes.StringDataType) or isinstance(dt, typelib_base_datatypes.PrimitiveInt) or \
           isinstance(dt, typelib_base_datatypes.EnumDataType) or _is_conv_type(dt)


def _get_datatype_considering_optionals(dt, isOpt):
    if isOpt:  # isoptional
        if _is_conv_type(dt):
            return typelib_base_datatypes.OptionalConversionDataType(dt)
        else:
            return typelib_base_datatypes.OptionalDataType(dt)
    else:
        return dt



def _deserializeInputParametersAndCreateComplexOutParameters(deserializer, prototype, stored_raw):
    returnList = []
    for paramDef in prototype._param_list:
        val = None

        if paramDef.inout_type != ParamInOutEnum.Out:
            dt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)
            val = dt.deserialize(deserializer, stored_raw)
        else:
            val = paramDef.datatype.initial_value()

        if _is_conv_type(paramDef.datatype):
            val = val.impl_value

        if (_is_primitive_type(paramDef.datatype) or paramDef.is_opt):
            if paramDef.inout_type == ParamInOutEnum.Out:
                outParamVal = OutParameter()
                outParamVal.value = val
                val = outParamVal
            elif paramDef.inout_type == ParamInOutEnum.InOut:
                val = InOutParameter(val)

        returnList.append(val)

    return returnList


def _serializeOutputParametersComplexInPlace(serializer, prototype, returnValue, inParamsAndComplexOutParams):
    paramIterator = iter(inParamsAndComplexOutParams)

    if prototype._return_datatype is not None:
        if _is_conv_type(prototype._return_datatype):
            _conv_serialization_param(serializer, prototype._return_datatype, prototype._return_datatype, returnValue)
        else:
            prototype._return_datatype.serialize(serializer, returnValue, False)

    for paramDef in prototype._param_list:
        currentParam = next(paramIterator)

        convType = _is_conv_type(paramDef.datatype)
        primitiveType = _is_primitive_type(paramDef.datatype)

        if paramDef.inout_type != ParamInOutEnum.In:
            if primitiveType or paramDef.is_opt:
                val = currentParam.value
            else:
                val = currentParam

            optDt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)

            if convType:
                _conv_serialization_param(serializer, paramDef.datatype, optDt, val)
            else:
                optDt.serialize(serializer, val, False)


def _serializeParameters(serializer, method_prototype, skipped_param_type, values):
        values_iter = iter(values)      

        serializer.BeginSerialization()

        if skipped_param_type == ParamInOutEnum.In and method_prototype._return_datatype is not None:
            method_prototype._return_datatype.serialize(serializer, next(values_iter), False)
      
        for paramDef in method_prototype._param_list:
            if paramDef.inout_type != skipped_param_type:
                optDt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)
                convType = _is_conv_type(paramDef.datatype)
                param_value = next(values_iter)
                
                if convType and not isinstance(param_value, typelib_base_datatypes.DataTypeWithConversion):
                    _conv_serialization_param(serializer, paramDef.datatype, optDt, param_value)
                else:
                    optDt.serialize(serializer, param_value, False)

        serializer.EndSerialization()

def _get_impl_values(method_prototype, skipped_param_type, values):
    values_iter = iter(values)
    ret_values = []

    if skipped_param_type == ParamInOutEnum.In and method_prototype._return_datatype is not None:
        val = next(values_iter)
        if _is_conv_type(method_prototype._return_datatype):
            val = val.impl_value
        ret_values.append(val)
      
    for paramDef in method_prototype._param_list:
        if paramDef.inout_type != skipped_param_type:
            dt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)
            val = next(values_iter)
            if _is_conv_type(paramDef.datatype):
                val = val.impl_value
            ret_values.append(val)

    return ret_values

def _deserializeParameters(deserializer, method_prototype, skipped_param_type, stored_raw):   
    outParamValues = []
        
    deserializer.BeginDeserialization()

    if skipped_param_type == ParamInOutEnum.In and method_prototype._return_datatype is not None:
        outParamValues.append(method_prototype._return_datatype.deserialize(deserializer, stored_raw))
      
    for paramDef in method_prototype._param_list:
        if paramDef.inout_type != skipped_param_type:
            dt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)
            outParamValues.append(dt.deserialize(deserializer, stored_raw))

    deserializer.EndDeserialization()

    return outParamValues

    
def _deserializeOutputParametersInPlace(deserializer, prototype, params, stored_raw):
    def _deserialize_and_convert_to_impl_value(effdt, optdt):
        val = optdt.deserialize(deserializer, stored_raw)
        if _is_conv_type(effdt):
            val = val.impl_value
        return val
    
    ret = None
  
    if prototype._return_datatype is not None:
        ret = _deserialize_and_convert_to_impl_value(prototype._return_datatype, prototype._return_datatype)

    param_iter = iter(params)
    for paramDef in prototype._param_list:
        current_param = next(param_iter)
        if paramDef.inout_type != ParamInOutEnum.In:  # skip in parameter
            optDt = _get_datatype_considering_optionals(paramDef.datatype, paramDef.is_opt)

            if _is_primitive_type(optDt) or paramDef.is_opt:
                current_param.value = _deserialize_and_convert_to_impl_value(paramDef.datatype, optDt)
            else:
                optDt.deserialize_in_place(deserializer, current_param, stored_raw)

    return ret


class ParameterBase(Generic[T]):
    def __init__(self, parameter_number, skipped_type):
        self._parameter_number = parameter_number
        self._skipped_type = skipped_type
        if parameter_number == 0:
          self._dt = self._get_method_prototype()._return_datatype
        else:
          self._dt = self._get_method_prototype()._param_list[parameter_number-1].datatype
        
    def _deserializeValue(self):
        return self._deserialize_parameter(self._deserializer, self._skipped_type)

    def _serializeValue(self, new_value):
        method_prototype = self._get_method_prototype()
        values = _deserializeParameters(self._deserializer, method_prototype, self._skipped_type, self._stored_raw)
        if self._parameter_number == 0:
            num = 0
        else:
            num = len([param for param in method_prototype._param_list[0:self._parameter_number] if param.inout_type != self._skipped_type])

        values[num] = new_value

        _serializeParameters(self._serializer, method_prototype, self._skipped_type, values)

    def _deserialize_parameter(self, deserializer, skipped_param_type):
        method_prototype = self._get_method_prototype()
        values = _deserializeParameters(deserializer, method_prototype, skipped_param_type, self._get_stored_raw())
        param_value_iter = iter(values)

        if skipped_param_type == ParamInOutEnum.In and method_prototype._return_datatype is not None:
            next(param_value_iter)

            if self._parameter_number == 0:
                return values[0]

        number = 1
        for paramDef in method_prototype._param_list:
            if paramDef.inout_type != skipped_param_type:
                val = next(param_value_iter)
                if number == self._parameter_number:
                    return val
                
            number += 1


class ParameterReadOnlyConversionPhysRawSymb(ParameterBase, typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], typelib_common.ReadOnlySymbValueMixin[T4], Generic[T, T2, T3, T4]):
    pass  

class ParameterReadWriteConversionPhysRawSymb(ParameterBase, typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T3, T4]):
    pass  

class ParameterReadOnlyConversionPhysRaw(ParameterBase, typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlyRawTypeMixin[T3], Generic[T, T2, T3]):
    pass  

class ParameterReadWriteConversionPhysRaw(ParameterBase, typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T2, T3]):
    pass  

class ParameterReadOnlyConversionRaw(ParameterBase, typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyRawTypeMixin[T3], Generic[T, T3]):
    pass  

class ParameterReadWriteConversionRaw(ParameterBase, typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWriteRawTypeMixin[T3], Generic[T, T3]):
    pass  

class ParameterReadOnlyConversionPhysSymb(ParameterBase, typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], typelib_common.ReadOnlySymbValueMixin[T4], Generic[T, T2, T4]):
    pass  

class ParameterReadWriteConversionPhysSymb(ParameterBase, typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], typelib_common.ReadWriteSymbValueMixin[T4], Generic[T, T2, T4]):
    pass  

class ParameterReadOnlyConversionPhys(ParameterBase, typelib_common.ReadOnlyConvMixin[T], typelib_common.ReadOnlyPhysMixin[T2], Generic[T, T2]):
    pass  

class ParameterReadWriteConversionPhys(ParameterBase, typelib_common.ReadWriteConvMixin[T], typelib_common.ReadWritePhysMixin[T2], Generic[T, T2]):
    pass  

class ParameterReadOnly(ParameterBase, typelib_common.CopyMixin[T], Generic[T]):
    pass  

class ParameterReadWrite(ParameterBase, typelib_common.CopyMixin[T], Generic[T]):
    pass  

class CallAsyncCallback:
    def __init__(self, cco, callback, pyMethod):
        self._cco = cco
        self._callback = callback
        self._pyMethod = pyMethod

    def __call__(self):
        if (self._callback is not None) and (self._cco.GetCallState() is not vector.canoe.cla.CallState_Discarded):
            deserializer = self._cco.GetOutputParametersDeserializer()
            outParamValues = _deserializeParameters(deserializer, self._pyMethod._method_prototype, ParamInOutEnum.In, self._pyMethod._stored_rx_raw)
            outParamValuesImpl = _get_impl_values(self._pyMethod._method_prototype, ParamInOutEnum.In, outParamValues)
            self._callback(*outParamValuesImpl)

        self._callback = None
        self._cco = None


class CallContext:
    def __init__(self, cco, prefer_out_values: bool, stored_in_raw: bool, stored_out_raw: bool, method_prototype):
        self._cco = cco
        self._method_prototype = method_prototype
        self._prefer_out_values = prefer_out_values
        self._stored_in_raw = stored_in_raw
        self._stored_out_raw = stored_out_raw

    def _use_out_values(self, parameter_number) -> bool:
        if parameter_number == 0:
            return True

        param_inout_type = self._method_prototype._param_list[parameter_number-1].inout_type
        if param_inout_type == ParamInOutEnum.In or (param_inout_type == ParamInOutEnum.InOut and not self._prefer_out_values):
            return False
        else:
            return True

    def _set_cco_parameter(self, parameter_number, new_value):
        if self._use_out_values(parameter_number):
            deserializer = self._cco.GetOutputParametersDeserializer()
            serializer = self._cco.GetOutputParametersSerializer()
            skipped_type = ParamInOutEnum.In
            stored_raw = self._stored_out_raw
        else:
            deserializer = self._cco.GetInputParametersDeserializer()
            serializer = self._cco.GetInputParametersSerializer()
            skipped_type =  ParamInOutEnum.Out
            stored_raw = self._stored_in_raw

        values = _deserializeParameters(deserializer, self._method_prototype, skipped_type, stored_raw)
        if parameter_number == 0:
            num = 0
        else:
            num = len([param for param in self._method_prototype._param_list[0:parameter_number] if param.inout_type != skipped_type])

        values[num] = new_value

        _serializeParameters(serializer, self._method_prototype, skipped_type, values)

    def _get_cco_parameter(self, parameter_number, base):
        class _CallContextParameter(base, Generic[T]):
            def __init__(self, parameter_number, py_cco):
                self._cco = py_cco
                if py_cco._use_out_values(parameter_number):
                    self._deserializer = self._cco._cco.GetOutputParametersDeserializer()
                    self._serializer = self._cco._cco.GetOutputParametersSerializer()
                    skipped_type =  ParamInOutEnum.In
                    self._stored_raw = py_cco._stored_out_raw   
                else:
                    self._deserializer = self._cco._cco.GetInputParametersDeserializer()
                    self._serializer = self._cco._cco.GetInputParametersSerializer()
                    skipped_type =  ParamInOutEnum.Out
                    self._stored_raw = py_cco._stored_in_raw
                ParameterBase.__init__(self, parameter_number, skipped_type)

            def _get_method_prototype(self):
                return self._cco._method_prototype

            def _get_stored_raw(self) -> bool:
                return self._stored_raw

        return _CallContextParameter(parameter_number, self)


class LatestCallOrReturnParameter:
    def __init__(self, latest_call_or_return):
        self._latest_call_or_return = latest_call_or_return
        self._deserializer = self._latest_call_or_return._ve.GetDeserializer()

    def _get_method_prototype(self):
        return self._latest_call_or_return._method_prototype

    def _get_stored_raw(self) -> bool:
        return self._latest_call_or_return._stored_raw


class LatestCallOrReturn(typelib_common.ValueEntity, typelib_common.OnUpdateMixin, typelib_common.OnChangeMixin):
    def __init__(self, method, value_entity: object, stored_raw: bool):
        super().__init__(value_entity)
        self._method = method
        self._stored_raw = stored_raw

    def _get_latest_call_or_return_parameter(self, base):
        class _LatestCallOrReturnParameter(base, Generic[T]):
            def __init__(self, parameter_number, latest_call_or_return, skipped_type):
                self._latest_call_or_return = latest_call_or_return
                self._deserializer = self._latest_call_or_return._ve.GetDeserializer()
                ParameterBase.__init__(self, parameter_number, skipped_type)
 
            def _get_method_prototype(self):
                return self._latest_call_or_return._method_prototype

            def _get_stored_raw(self) -> bool:
                return self._latest_call_or_return._stored_raw
        
        return _LatestCallOrReturnParameter


class LatestCall(LatestCallOrReturn):
    def __init__(self, method, stored_raw: bool):
        super().__init__(method, method._method.GetLatestCall(), stored_raw)


class LatestReturn(LatestCallOrReturn):
    def __init__(self, method, stored_raw: bool):
        super().__init__(method, method._method.GetLatestReturn(), stored_raw)

class MethodBase(Generic[T, T2]):

    _method_prototype = None
    CallContext: Callable = lambda cco: None
    
    def __init__(self, doInterfaceImpl, doMethodPath, method, latest_call_type, latest_return_type):
        self._method = method
        self._doMethodPath = doMethodPath
        self._doInterfaceImpl = doInterfaceImpl
        self.LatestCall : T =  latest_call_type(self, self._stored_rx_raw)
        self.LatestReturn : T2 = latest_return_type(self, self._stored_rx_raw)

    @property
    def path(self):
        return self._doInterfaceImpl._doPath + "." + self._doMethodPath

class ProvidedMethod(MethodBase[T, T2], Generic[T, T2]):
    _stored_rx_raw = True
    def __init__(self, do, doMethodPath, method, latest_call_type, latest_return_type):
        super(ProvidedMethod, self).__init__(do, doMethodPath, method, latest_call_type, latest_return_type)

    @staticmethod
    def _CallImplementationCallback(providedmethod_weakref, cco, callback):
        if providedmethod_weakref():
            providedmethod = providedmethod_weakref()
            deserializer = cco.GetInputParametersDeserializer()
            deserializer.BeginDeserialization()
            inParamsAndComplexOutParams = _deserializeInputParametersAndCreateComplexOutParameters(deserializer, providedmethod._method_prototype, providedmethod._stored_rx_raw)
            deserializer.EndDeserialization()

            returnValue = callback(*inParamsAndComplexOutParams)

            serializer = cco.GetOutputParametersSerializer()
            serializer.BeginSerialization()
            _serializeOutputParametersComplexInPlace(serializer, providedmethod._method_prototype, returnValue, inParamsAndComplexOutParams)
            serializer.EndSerialization()

    def _DoSetCallHandler(self, callback):
        if callback is None:
            self._method.SetCallback(vector.canoe.cla.ProviderImplementationCallbackFunction(None))
        else:
            self_weakref = weakref.ref(self)
            cbWrapper = createProviderImplementationCallbackFunction(lambda cco: ProvidedMethod._CallImplementationCallback(self_weakref, cco, callback))
            self._method.SetCallback(cbWrapper)


class ConsumedMethod(MethodBase[T, T2], Generic[T, T2]):
    _stored_rx_raw = True
    def __init__(self, do, doMethodPath, method, latest_call_type, latest_return_type):
        super(ConsumedMethod, self).__init__(do, doMethodPath, method, latest_call_type, latest_return_type)

    def _DoCallAsync(self, callback, inParams, cco_type: CallContext = None):
        cco = self._method.CreateCallContext()

        serializer = cco.GetInputParametersSerializer()
        _serializeParameters(serializer, self._method_prototype, ParamInOutEnum.Out, inParams)
        
        if callback is None:
            if cco_type is None:
                raise ValueError(f"cco_type must not be None if no callback is provided.")
            py_cco = cco_type(cco, False, False, True)
            def _dummy_callback(*args):
                py_cco._prefer_out_values = True

            cbWrapper = createConsumerCallContextCallbackFunction(CallAsyncCallback(cco, _dummy_callback, self))
            cco.CallAsync(cbWrapper)
            return py_cco
        else:
            cbWrapper = createConsumerCallContextCallbackFunction(CallAsyncCallback(cco, callback, self))
            cco.CallAsync(cbWrapper)


class CallSyncMixin:
    def _DoCallSync(self, params):
        cco = self._method.CreateCallContext()

        only_in_params = []
        param_iter = iter(params)
        for paramDef in self._method_prototype._param_list:
            current_param = next(param_iter)
            if paramDef.inout_type != ParamInOutEnum.Out:
                if paramDef.inout_type == ParamInOutEnum.InOut and (_is_primitive_type(paramDef.datatype) or paramDef.is_opt):
                    only_in_params.append(current_param.value)
                else:
                    only_in_params.append(current_param)

        serializer = cco.GetInputParametersSerializer()
        _serializeParameters(serializer, self._method_prototype, ParamInOutEnum.Out, only_in_params)

        cco.CallSync()

        deserializer = cco.GetOutputParametersDeserializer()
        deserializer.BeginDeserialization()
        ret_value = _deserializeOutputParametersInPlace(deserializer, self._method_prototype, params, self._stored_rx_raw)
        deserializer.EndDeserialization()
        
        return ret_value


class InternalMethod(ProvidedMethod[T, T2], ConsumedMethod[T, T2], CallSyncMixin, Generic[T, T2]):
    _stored_rx_raw = False
    def __init__(self, do, doMethodPath, method, latest_call_type, latest_return_type):
        MethodBase.__init__(self, do, doMethodPath, method, latest_call_type, latest_return_type)
